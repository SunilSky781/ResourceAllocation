package com.resource.ResourceAllocation_As;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.resource.ResourceAllocation_As.service.ResourceAllocationService;

@SpringBootTest
class ResourceAllocationAsApplicationTests {

	  @Autowired
	    private ResourceAllocationService resourceAllocationService;

	    @Test
	    public void testMicroserviceProjectResources() {
	        List<String> resources = resourceAllocationService.findResourcesForMicroserviceProject();
	        assertThat(resources).containsExactly("Thompson", "Kumar");
	    }

	    @Test
	    public void testCloudProjectResources() {
	        List<String> resources = resourceAllocationService.findResourcesForCloudProject();
	        assertThat(resources).containsExactly("Aisha", "Dennis");
	    }

}
