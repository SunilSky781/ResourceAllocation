package com.resource.ResourceAllocation_As.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.resource.ResourceAllocation_As.model.Resource;
import com.resource.ResourceAllocation_As.repository.ResourceRepository;

@Service
public class ResourceAllocationService {
	  @Autowired
	    private ResourceRepository resourceRepository;

	    public List<String> findResourcesDynamically(List<String> skills, Integer maxExperience) {
	        String skillsString = skills != null ? String.join(", ", skills) : null;
	        
	        return resourceRepository.findResourcesDynamically(skillsString, maxExperience)
	                .stream()
	                .map(Resource::getResourceName)
	                .collect(Collectors.toList());
	    }

	    // Specific use case methods
	    public List<String> findResourcesForMicroserviceProject() {
	        return findResourcesDynamically(
	            Arrays.asList("Java", "Redis", "Javascript"), 
	            null
	        );
	    }

	    public List<String> findResourcesForCloudProject() {
	        return findResourcesDynamically(
	            Arrays.asList("Mysql", "Docker", "Spring", "React"), 
	            10
	        );
	    }
}
