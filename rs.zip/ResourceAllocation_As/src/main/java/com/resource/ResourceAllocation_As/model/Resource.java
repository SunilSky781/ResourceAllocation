package com.resource.ResourceAllocation_As.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "resources")
public class Resource {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long resourceId;
	    
	    private String resourceName;
	    private Integer experience;
	    private String skills;
		public Long getResourceId() {
			return resourceId;
		}
		public void setResourceId(Long resourceId) {
			this.resourceId = resourceId;
		}
		public String getResourceName() {
			return resourceName;
		}
		public void setResourceName(String resourceName) {
			this.resourceName = resourceName;
		}
		public Integer getExperience() {
			return experience;
		}
		public void setExperience(Integer experience) {
			this.experience = experience;
		}
		public String getSkills() {
			return skills;
		}
		public void setSkills(String skills) {
			this.skills = skills;
		}
	    
	    
	    
}
