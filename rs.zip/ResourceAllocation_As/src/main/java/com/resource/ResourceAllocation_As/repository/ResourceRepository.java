package com.resource.ResourceAllocation_As.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.resource.ResourceAllocation_As.model.Resource;
@Repository
public interface ResourceRepository extends JpaRepository<Resource, Long> {
	  @Query("SELECT r FROM Resource r WHERE " +
	           "(:skills IS NULL OR " +
	           "LOWER(r.skills) LIKE LOWER(CONCAT('%', REPLACE(:skills, ', ', '%'), '%'))) " +
	           "AND (:maxExperience IS NULL OR r.experience < :maxExperience)")
	    List<Resource> findResourcesDynamically(
	        @Param("skills") String skills,
	        @Param("maxExperience") Integer maxExperience
	    );

//	Collection<String> findResourcesDynamically(String skillsString, Integer maxExperience);
}
