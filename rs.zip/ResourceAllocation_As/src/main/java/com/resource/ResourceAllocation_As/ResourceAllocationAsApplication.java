package com.resource.ResourceAllocation_As;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourceAllocationAsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceAllocationAsApplication.class, args);
		System.out.println("Estuate private ltd company.....");
	}

}
