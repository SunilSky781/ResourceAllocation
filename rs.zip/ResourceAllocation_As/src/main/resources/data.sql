INSERT INTO resources (resource_name, experience, skills) VALUES 
('Dennis', 4, 'Java, Spring, JMS, mysql, Angular, React, Web services, Nodejs'),
('Thompson', 7, 'Java, oracle, React, Angular, Javascript, REST API'),
('Kim', 12, 'Java, JSP, Spring, Oracle, Mysql, PostgreSQL, mongo, Rest API, web services, docker, Redis'),
('Aisha', 9, 'Angular, Javascript, Nodejs, Rest API, Web services, Docker, SQL server, PostgreSQL'),
('Maya', 5, 'Spring, Spring boot, Hibernate, MySQL, PostgreSQL, Nodejs, python'),
('Kumar', 3, 'Java, Redis, Mysql, Javascript');